    let db = { caixas: [], prateleiras: [], processos: [], unidades: [] };
    let edit=null, pastaHandle, lastHash = "";
    let _dashChart1 = null, _dashChart2 = null;
    let dashProcessoInicializado = false;
    const ERP_PAGE_ID = window.ERP_PAGE_ID || "index";

    const IDB_NOME = "erp-estoque-fs";
    const IDB_STORE = "config";
    const IDB_KEY_PASTA = "directoryHandle";
    const IDB_VERSAO = 2;
    let pastaHandlePendente = null;

    function abrirIndexedDB(){
        return new Promise((resolve, reject) => {
            const req = indexedDB.open(IDB_NOME, IDB_VERSAO);
            req.onerror = () => reject(req.error);
            req.onsuccess = () => resolve(req.result);
            req.onupgradeneeded = (ev) => {
                const database = ev.target.result;
                if(!database.objectStoreNames.contains(IDB_STORE))
                    database.createObjectStore(IDB_STORE);
            };
        });
    }

    async function salvarPastaNoIndice(dirHandle){
        try{
            const idb = await abrirIndexedDB();
            await new Promise((resolve, reject) => {
                const tx = idb.transaction(IDB_STORE, "readwrite");
                tx.oncomplete = () => resolve();
                tx.onabort = () => reject(tx.error || new Error("IndexedDB abort"));
                tx.onerror = () => reject(tx.error);
                tx.objectStore(IDB_STORE).put(dirHandle, IDB_KEY_PASTA);
            });
            const nome = dirHandle && dirHandle.name ? dirHandle.name : "";
            if(nome){
                localStorage.setItem("pastaId", nome);
                localStorage.setItem("pastaNomeUltima", nome);
            }
        }catch(e){
            console.error("Falha ao guardar pasta no IndexedDB:", e);
            alert("Não foi possível memorizar a pasta neste navegador. Abra o app por http://localhost ou HTTPS e use Chrome/Edge. Evite abrir o arquivo direto (file://).");
        }
    }

    async function lerPastaDoIndice(){
        const idb = await abrirIndexedDB();
        return new Promise((resolve, reject) => {
            const tx = idb.transaction(IDB_STORE, "readonly");
            const req = tx.objectStore(IDB_STORE).get(IDB_KEY_PASTA);
            req.onsuccess = () => resolve(req.result || null);
            req.onerror = () => reject(req.error);
        });
    }

    /** Só consulta — no carregamento da página não chame requestPermission (exige clique do usuário). */
    async function permissaoJaConcedida(handle){
        const opt = { mode: "readwrite" };
        try{
            if(typeof handle.queryPermission !== "function") return true;
            return (await handle.queryPermission(opt)) === "granted";
        }catch(e){
            console.warn(e);
            return false;
        }
    }

    /** Depois do seletor de pasta o navegador ainda está em “gesto do usuário”; pode pedir permissão. */
    async function garantirPermissaoAposSelecao(handle){
        const opt = { mode: "readwrite" };
        try{
            if(typeof handle.queryPermission !== "function") return true;
            if((await handle.queryPermission(opt)) === "granted") return true;
            if(typeof handle.requestPermission === "function")
                return (await handle.requestPermission(opt)) === "granted";
        }catch(e){ console.warn(e); }
        return false;
    }

    function mostrarBarraReconectar(nomePasta){
        const bar = document.getElementById("barraReconectarPasta");
        const txt = document.getElementById("barraReconectarTexto");
        if(!bar || !txt) return;
        const n = nomePasta || localStorage.getItem("pastaNomeUltima") || "sua pasta de dados";
        txt.innerHTML = "Esta sessão precisa de <strong>um clique</strong> para voltar a acessar a pasta memorizada: <strong>" + escapeHtmlUi(n) + "</strong>. (O navegador exige isso ao reabrir.)";
        bar.style.display = "flex";
        const slBar = document.getElementById("syncLabel");
        if(slBar) slBar.innerText = "Aguardando permissão…";
    }

    function esconderBarraReconectar(){
        const bar = document.getElementById("barraReconectarPasta");
        if(bar) bar.style.display = "none";
        pastaHandlePendente = null;
    }

    function escapeHtmlUi(s){
        const d = document.createElement("div");
        d.textContent = s;
        return d.innerHTML;
    }

    async function reconectarPastaSalva(){
        let h = pastaHandlePendente || await lerPastaDoIndice();
        if(!h){
            alert("Nenhuma pasta memorizada. Use o menu → Alterar pasta.");
            return selecionarPasta();
        }
        try{
            if(typeof h.requestPermission !== "function"){
                pastaHandle = h;
                await salvarPastaNoIndice(pastaHandle);
                await carregarDB();
                esconderBarraReconectar();
                return;
            }
            const r = await h.requestPermission({ mode: "readwrite" });
            if(r !== "granted"){
                alert("Permissão negada. Tente de novo ou escolha outra pasta.");
                return;
            }
            pastaHandle = h;
            pastaHandlePendente = null;
            await salvarPastaNoIndice(pastaHandle);
            await carregarDB();
            esconderBarraReconectar();
        }catch(e){
            console.error(e);
            alert("Não foi possível restabelecer o acesso. Escolha a pasta novamente no menu.");
        }
    }

    async function escolherOutraPastaManual(){
        esconderBarraReconectar();
        await selecionarPasta();
        if(!pastaHandle){
            const slM = document.getElementById("syncLabel");
            if(slM) slM.innerText = "Escolha a pasta no menu (☰)";
        }
    }

    window.onload = async function(){
        if(ERP_PAGE_ID === "lancamento" && !new URLSearchParams(location.search).has("edit"))
            sessionStorage.removeItem("erpEditParam");
        await inicializarPasta();
        if(ERP_PAGE_ID === "dashboard") atualizarDashboard();
        if(ERP_PAGE_ID === "mapa") mapa();
        if(ERP_PAGE_ID === "avulsas") renderAvulsas();
        setInterval(async () => { if(pastaHandle && edit===null) await carregarDB(true); }, 5000);
    };

    /** Guarda ?edit= até o banco existir (ex.: permissão da pasta ainda pendente). */
    function aplicarEdicaoSeNecessario(){
        const params = new URLSearchParams(location.search);
        let q = params.get("edit");
        if(q !== null && q !== ""){
            sessionStorage.setItem("erpEditParam", q);
            history.replaceState({}, "", location.pathname + location.hash);
        } else {
            q = sessionStorage.getItem("erpEditParam");
        }
        if(q === null || q === "") return;
        const i = parseInt(q, 10);
        if(isNaN(i) || !db.caixas[i]) return;
        sessionStorage.removeItem("erpEditParam");
        preencherFormularioEdicao(i);
    }

    async function inicializarPasta(){
        if(!window.showDirectoryPicker){
            alert("Este navegador não suporta escolha de pasta (use Chrome ou Edge em ambiente seguro https/localhost).");
            return;
        }
        if(window.location.protocol === "file:"){
            console.warn("Abrir o HTML por file:// limita a memória da pasta. Prefira abrir pela mesma origem (ex.: Live Server ou python -m http.server).");
        }
        try{
            const salvo = await lerPastaDoIndice();
            if(salvo){
                pastaHandlePendente = salvo;
                if(await permissaoJaConcedida(salvo)){
                    pastaHandle = salvo;
                    pastaHandlePendente = null;
                    await carregarDB();
                    if(pastaHandle && pastaHandle.name){
                        localStorage.setItem("pastaId", pastaHandle.name);
                        localStorage.setItem("pastaNomeUltima", pastaHandle.name);
                    }
                    esconderBarraReconectar();
                    return;
                }
                mostrarBarraReconectar(salvo.name);
                return;
            }
        }catch(e){
            console.warn("Não foi possível ler a pasta salva:", e);
        }
        await selecionarPasta();
        if(!pastaHandle){
            const slI = document.getElementById("syncLabel");
            if(slI) slI.innerText = "Escolha a pasta no menu (☰)";
        }
    }

    async function selecionarPasta(){
        esconderBarraReconectar();
        try{
            pastaHandle = await window.showDirectoryPicker({ mode: "readwrite" });
            const permitido = await garantirPermissaoAposSelecao(pastaHandle);
            if(!permitido){
                pastaHandle = null;
                return alert("Permissão negada. A pasta não pôde ser usada.");
            }
            await salvarPastaNoIndice(pastaHandle);
            await carregarDB();
        }catch(err){
            if(err && err.name !== "AbortError")
                console.error(err);
        }
    }

    async function carregarDB(silencioso = false){
        if(!pastaHandle) return;
        try{
            const arquivo = await pastaHandle.getFileHandle("banco_erp.json",{create:true});
            const file = await arquivo.getFile();
            const texto = await file.text();

            if (texto !== lastHash) {
                lastHash = texto;
                db = texto ? JSON.parse(texto) : { caixas: [], prateleiras: [], processos: [], unidades: [] };
                if(!db.processos) db.processos = [];
                if(!db.unidades) db.unidades = [];
                garantirHistoricoCaixas();
                normalizarEliminadasELocaisAvulsos();
                atualizarInterface();
                const slSync = document.getElementById("syncLabel");
                if(slSync) slSync.innerText = "Sinc.: " + new Date().toLocaleTimeString();
                if(ERP_PAGE_ID === "lancamento") aplicarEdicaoSeNecessario();
            }
        }catch(err){ console.error(err); }
    }

    async function salvarDB(){
        const arquivo = await pastaHandle.getFileHandle("banco_erp.json",{create:true});
        const writable = await arquivo.createWritable();
        const conteudo = JSON.stringify(db, null, 2);
        await writable.write(conteudo);
        await writable.close();
        lastHash = conteudo;
    }

    // ---------------- GESTÃO DE PRATELEIRAS ----------------
    async function adicionarPrateleira(){
        const nome = document.getElementById("nomePrateleiraNova").value.trim();
        if(!nome) return;
        if(db.prateleiras.find(p => p.nome === nome)) return alert("Prateleira já existe!");
        db.prateleiras.push({ nome: nome, capacidade: 78 });
        await salvarDB();
        document.getElementById("nomePrateleiraNova").value = "";
        atualizarInterface();
    }

    async function excluirPrateleira(nome){
        if(db.caixas.some(c => caixaOcupaSlot(c) && c.prateleira === nome)) return alert("Não é possível excluir: há caixas alocadas nesta prateleira!");
        if(confirm(`Excluir prateleira ${nome}?`)){
            db.prateleiras = db.prateleiras.filter(p => p.nome !== nome);
            await salvarDB();
            atualizarInterface();
        }
    }

    // ---------------- GESTÃO DE PROCESSOS ----------------
    async function adicionarProcesso(){
        const nome = document.getElementById("nomeProcessoNovo").value.trim();
        if(!nome) return;
        if(db.processos.includes(nome)) return alert("Processo já existe!");
        db.processos.push(nome);
        await salvarDB();
        document.getElementById("nomeProcessoNovo").value = "";
        atualizarInterface();
    }

    async function excluirProcesso(nome){
        if(db.caixas.some(c => c.processos && c.processos.includes(nome)))
            return alert("Não é possível excluir: existem caixas vinculadas a este processo!");
        if(confirm(`Excluir processo ${nome}?`)){
            db.processos = db.processos.filter(p => p !== nome);
            await salvarDB();
            atualizarInterface();
        }
    }

    async function adicionarUnidade(){
        if(!db.unidades) db.unidades = [];
        const nome = document.getElementById("nomeUnidadeNova").value.trim();
        if(!nome) return;
        if(db.unidades.includes(nome)) return alert("Esta unidade já existe!");
        db.unidades.push(nome);
        await salvarDB();
        document.getElementById("nomeUnidadeNova").value = "";
        atualizarInterface();
    }

    async function excluirUnidade(nome){
        if(db.caixas.some(c => c.unidade === nome))
            return alert("Não é possível excluir: existem caixas vinculadas a esta unidade!");
        if(confirm("Excluir unidade \"" + nome + "\"?")){
            db.unidades = db.unidades.filter(u => u !== nome);
            await salvarDB();
            atualizarInterface();
        }
    }

    // ---------------- INTERFACE ----------------
    function atualizarInterface(){
        renderSelectPrateleiras();
        renderSelectUnidades();
        renderCheckboxesProcessos();
        renderConfigProcessos();
        renderConfigUnidades();
        renderConfigPrateleiras();
        listar();
        if(document.getElementById("dashboardKpis")) atualizarDashboard();
        if(document.getElementById("listaAvulsas")) renderAvulsas();
        if(document.getElementById("mapaLancamento")) renderMapaLancamento();
        if(document.getElementById("mapa")) mapa();
    }

    function renderSelectPrateleiras(){
        const sel = document.getElementById("prateleiraSelect");
        if(!sel) return;
        const valorAtual = sel.value;
        sel.innerHTML = '<option value="">— Caixa avulsa (sem prateleira) —</option>';
        db.prateleiras.forEach(p => {
            const opt = document.createElement("option");
            opt.value = p.nome; opt.text = p.nome;
            sel.appendChild(opt);
        });
        if([...sel.options].some(o => o.value === valorAtual)) sel.value = valorAtual;
        const st = document.getElementById("status") && document.getElementById("status").value;
        sel.disabled = st === "Eliminada";
    }

    function renderSelectUnidades(){
        const sel = document.getElementById("unidadeSelect");
        if(!sel) return;
        const valorAtual = sel.value;
        sel.innerHTML = '<option value="">— Não informada —</option>';
        (db.unidades || []).slice().sort((a, b) => a.localeCompare(b, "pt")).forEach(u => {
            const opt = document.createElement("option");
            opt.value = u;
            opt.textContent = u;
            sel.appendChild(opt);
        });
        if(valorAtual && ![...sel.options].some(o => o.value === valorAtual)){
            const opt = document.createElement("option");
            opt.value = valorAtual;
            opt.textContent = valorAtual + " (cadastre em Unidades)";
            sel.appendChild(opt);
        }
        if([...sel.options].some(o => o.value === valorAtual)) sel.value = valorAtual;
    }

    function renderConfigUnidades(){
        const tbody = document.getElementById("listaUnidadesConfig");
        if(!tbody) return;
        tbody.innerHTML = "";
        (db.unidades || []).slice().sort((a, b) => a.localeCompare(b, "pt")).forEach(u => {
            tbody.innerHTML += "<tr><td><b>" + escModal(u) + "</b></td><td><button type=\"button\" style=\"background:#e74c3c\" onclick=\"excluirUnidade(" + JSON.stringify(u) + ")\">Excluir</button></td></tr>";
        });
    }

    function renderCheckboxesProcessos(){
        const container = document.getElementById("processosContainer");
        if(!container) return;
        container.innerHTML = db.processos.length === 0 ? "<small>Nenhum processo cadastrado</small>" : "";
        db.processos.forEach(proc => {
            container.innerHTML += `<label style="font-size:13px; cursor:pointer;"><input type="checkbox" name="procCheck" value="${proc}"> ${proc}</label>`;
        });
    }

    function renderConfigProcessos(){
        const tbody = document.getElementById("listaProcessosConfig");
        if(!tbody) return;
        tbody.innerHTML = "";
        db.processos.forEach(p => {
            tbody.innerHTML += `<tr><td>${p}</td><td><button style="background:#e74c3c" onclick="excluirProcesso('${p}')">Excluir</button></td></tr>`;
        });
    }

    function renderConfigPrateleiras(){
        const tbody = document.getElementById("listaPrateleirasConfig");
        if(!tbody) return;
        tbody.innerHTML = "";
        db.prateleiras.forEach(p => {
            const qtd = db.caixas.filter(c => caixaOcupaSlot(c) && c.prateleira === p.nome).length;
            tbody.innerHTML += `<tr><td><b>${p.nome}</b></td><td>${qtd} / 78</td><td><button style="background:#e74c3c" onclick="excluirPrateleira('${p.nome}')">Excluir</button></td></tr>`;
        });
    }

    // ---------------- HISTÓRICO DE CAIXAS ----------------
    function garantirHistoricoCaixas(){
        if(!db || !Array.isArray(db.caixas)) return;
        db.caixas.forEach(c => { if(!Array.isArray(c.historico)) c.historico = []; });
    }

    function normalizarEliminadasELocaisAvulsos(){
        if(!db || !Array.isArray(db.caixas)) return;
        db.caixas.forEach(c => {
            if(c.status === "Eliminada"){
                c.prateleira = "";
                c.nivel = 0;
                c.espaco = 0;
            } else if(!c.prateleira || !String(c.prateleira).trim() || c.status === "Avulsa"){
                c.status = "Avulsa";
                c.prateleira = "";
                c.nivel = 0; c.espaco = 0;
            }
        });
    }

    /** Caixa que conta no mapa ocupa um slot (não eliminada, com prateleira e N/S válidos). */
    function caixaOcupaSlot(c){
        if(!c || c.status === "Eliminada" || c.status === "Avulsa") return false;
        if(!c.prateleira || !String(c.prateleira).trim()) return false;
        const n = parseInt(c.nivel, 10), e = parseInt(c.espaco, 10);
        return !isNaN(n) && !isNaN(e) && n >= 1 && n <= 13 && e >= 1 && e <= 6;
    }

    function formatarLocalCaixa(c){
        if(!c) return "—";
        if(c.status === "Eliminada") return "Eliminada (sem prateleira)";
        if(!c.prateleira || !String(c.prateleira).trim()) return "Avulsa (sem prateleira)";
        return c.prateleira + " (N" + c.nivel + "-S" + c.espaco + ")";
    }

    function processosChave(arr){
        return JSON.stringify([...(arr || [])].slice().sort());
    }

    function snapshotCaixaParaHistorico(c){
        return {
            caixa: c.caixa,
            unidade: c.unidade || "",
            inicio: c.inicio || "",
            fim: c.fim || "",
            validade: c.validade || "",
            prateleira: c.prateleira || "",
            nivel: c.nivel,
            espaco: c.espaco,
            status: c.status || "",
            usuario: c.usuario || "",
            processos: c.processos ? [...c.processos] : []
        };
    }

    function extrairMudancasRegistro(antes, depois){
        const m = [];
        const rotulos = { caixa: "Número da caixa", unidade: "Unidade", inicio: "Data início", fim: "Data fim", validade: "Validade", status: "Status", usuario: "Responsável" };
        for(const k of ["caixa", "unidade", "inicio", "fim", "validade", "status", "usuario"]){
            const va = antes[k] != null ? String(antes[k]) : "";
            const vb = depois[k] != null ? String(depois[k]) : "";
            if(va !== vb) m.push({ campo: k, label: rotulos[k], de: va || "—", para: vb || "—" });
        }
        if(formatarLocalCaixa(antes) !== formatarLocalCaixa(depois))
            m.push({ campo: "localizacao", label: "Localização", de: formatarLocalCaixa(antes), para: formatarLocalCaixa(depois) });
        if(processosChave(antes.processos) !== processosChave(depois.processos)){
            const fa = (antes.processos && antes.processos.length) ? antes.processos.join(", ") : "—";
            const fb = (depois.processos && depois.processos.length) ? depois.processos.join(", ") : "—";
            m.push({ campo: "processos", label: "Processos", de: fa, para: fb });
        }
        return m;
    }

    function criarEntradaHistorico(tipo, mudancas, registradoPor){
        return {
            quandoISO: new Date().toISOString(),
            tipo: tipo,
            registradoPor: registradoPor != null ? String(registradoPor) : "",
            mudancas: mudancas
        };
    }

    function mudancasIniciaisCadastro(depois){
        return extrairMudancasRegistro({
            caixa: "", unidade: "", inicio: "", fim: "", validade: "", prateleira: "", nivel: 0, espaco: 0,
            status: "", usuario: "", processos: []
        }, depois);
    }

    function escModal(s){
        if(s == null || s === "") return "";
        const d = document.createElement("div");
        d.textContent = s;
        return d.innerHTML;
    }

    function renderHtmlHistorico(caixa){
        const lista = Array.isArray(caixa.historico) ? [...caixa.historico].reverse() : [];
        if(lista.length === 0)
            return "<div class=\"historico-vazio\">Nenhum evento registrado (caixa antiga ou sem alterações desde a atualização).</div>";
        return lista.map(h => {
            const dataStr = h.quandoISO ? new Date(h.quandoISO).toLocaleString("pt-BR") : "—";
            const tipoTxt = h.tipo === "criacao" ? "Cadastro" : "Edição";
            const por = h.registradoPor ? " · Responsável no formulário: " + escModal(h.registradoPor) : "";
            const mhtml = (h.mudancas || []).map(mu =>
                "<div class=\"historico-mud\"><strong>" + escModal(mu.label) + ":</strong> " +
                escModal(mu.de) + " → " + escModal(mu.para) + "</div>"
            ).join("");
            return "<div class=\"historico-item\"><div class=\"hi-top\">" + escModal(dataStr) + por +
                "</div><div class=\"hi-tipo\">" + tipoTxt + "</div>" + mhtml + "</div>";
        }).join("");
    }

    // ---------------- CRUD CAIXAS ----------------
    function atualizarResumoPosicao(){
        const el = document.getElementById("posicaoLancamentoResumo");
        if(!el) return;
        const st = document.getElementById("status") && document.getElementById("status").value;
        if(st === "Eliminada"){
            el.textContent = "Sem local físico — caixa eliminada não fica em prateleira.";
            el.classList.add("vazio");
            return;
        }
        const prat = document.getElementById("prateleiraSelect") && document.getElementById("prateleiraSelect").value;
        if(!prat){
            el.textContent = "Caixa avulsa — sem posição em prateleira.";
            el.classList.remove("vazio");
            return;
        }
        const n = parseInt(document.getElementById("nivel").value, 10);
        const e = parseInt(document.getElementById("espaco").value, 10);
        if(!isNaN(n) && !isNaN(e) && n >= 1 && n <= 13 && e >= 1 && e <= 6){
            el.textContent = "Posição selecionada: nível " + n + ", espaço " + e;
            el.classList.remove("vazio");
        } else {
            el.innerHTML = "Escolha um espaço <strong>verde</strong> no mapa desta prateleira.";
            el.classList.add("vazio");
        }
    }

    function onStatusLancamentoChange(){
        esconderMsgLancamentoOk();
        const st = document.getElementById("status").value;
        const selPrat = document.getElementById("prateleiraSelect");
        const ph = document.getElementById("mapaLancamentoPlaceholder");
        const mapEl = document.getElementById("mapaLancamento");
        const alerta = document.getElementById("alertaStatusLanc");
        if(st === "Eliminada"){
            if(selPrat){ selPrat.disabled = true; selPrat.value = ""; }
            document.getElementById("nivel").value = "";
            document.getElementById("espaco").value = "";
            if(alerta){
                alerta.style.display = "block";
                alerta.textContent = "Eliminada: não é permitido alocar em prateleira. O endereço será removido ao salvar.";
            }
            if(ph){
                ph.style.display = "block";
                ph.textContent = "Caixa eliminada não ocupa prateleira.";
            }
            if(mapEl){ mapEl.innerHTML = ""; mapEl.style.display = "none"; }
            atualizarResumoPosicao();
            return;
        }
        if(selPrat) selPrat.disabled = false;
        if(alerta) alerta.style.display = "none";
        if(ph){
            if(!selPrat || !selPrat.value){
                ph.style.display = "block";
                ph.textContent = "Selecione uma prateleira para o mapa ou deixe em branco para caixa avulsa.";
            }
        }
        atualizarResumoPosicao();
        if(selPrat && selPrat.value){ if(ph) ph.style.display = "none"; renderMapaLancamento(); }
        else { if(mapEl){ mapEl.innerHTML = ""; mapEl.style.display = "none"; } }
    }

    function esconderMsgLancamentoOk(){
        const ok = document.getElementById("msgLancamentoOk");
        if(ok) ok.style.display = "none";
    }

    function onPrateleiraLancamentoChange(){
        esconderMsgLancamentoOk();
        const stEl = document.getElementById("status");
        if(stEl.value === "Eliminada") return;

        // Se selecionar uma prateleira e o status for Avulsa, promove para Guardada automaticamente
        if(document.getElementById("prateleiraSelect").value && stEl.value === "Avulsa") stEl.value = "Guardada";

        document.getElementById("nivel").value = "";
        document.getElementById("espaco").value = "";
        atualizarResumoPosicao();
        const ph = document.getElementById("mapaLancamentoPlaceholder");
        const nome = document.getElementById("prateleiraSelect").value;
        if(ph){
            if(nome) ph.style.display = "none";
            else{
                ph.style.display = "block";
                ph.textContent = "Selecione uma prateleira para o mapa ou deixe em branco para caixa avulsa.";
            }
        }
        renderMapaLancamento();
    }

    function renderMapaLancamento(){
        const container = document.getElementById("mapaLancamento");
        if(!container) return;
        const st = document.getElementById("status") && document.getElementById("status").value;
        const ph = document.getElementById("mapaLancamentoPlaceholder");
        if(st === "Eliminada"){
            container.innerHTML = "";
            container.style.display = "none";
            return;
        }
        const nome = document.getElementById("prateleiraSelect").value;
        if(!nome){
            container.innerHTML = "";
            container.style.display = "none";
            return;
        }
        if(ph) ph.style.display = "none";
        container.style.display = "block";
        container.innerHTML = "";

        const selN = parseInt(document.getElementById("nivel").value, 10);
        const selE = parseInt(document.getElementById("espaco").value, 10);

        const box = document.createElement("div");
        box.className = "prateleiraBox";
        const h = document.createElement("h3");
        h.textContent = nome;
        box.appendChild(h);
        const leg = document.createElement("p");
        leg.className = "mapaLegendaLanc";
        leg.innerHTML = "<small>Verde = livre · Demais cores = ocupado (conforme status) · Moldura escura = posição escolhida para este formulário</small>";
        box.appendChild(leg);

        for(let n = 13; n >= 1; n--){
            const linha = document.createElement("div");
            linha.className = "nivel";
            const lab = document.createElement("div");
            lab.className = "nivelLabel";
            lab.textContent = "N" + n;
            linha.appendChild(lab);
                for(let e = 1; e <= 6; e++){
                const idx = db.caixas.findIndex((c, i) => caixaOcupaSlot(c) && c.prateleira === nome && c.nivel === n && c.espaco === e);
                const slot = document.createElement("div");
                slot.className = "slot";
                const ocupadoPorOutro = idx !== -1 && idx !== edit;
                const meuSlot = idx !== -1 && idx === edit;

                if(ocupadoPorOutro){
                    const ocx = db.caixas[idx];
                    slot.classList.add("ocupado" + ocx.status, "slotOcupadoOutro");
                    slot.textContent = ocx.caixa;
                    slot.title = "Ocupado — caixa " + ocx.caixa + (ocx.unidade ? " · " + ocx.unidade : "");
                    const cx = db.caixas[idx].caixa;
                    slot.onclick = () => alert("Este espaço já está ocupado pela caixa " + cx + ". Escolha outro.");
                } else if(meuSlot){
                    slot.classList.add("ocupado" + db.caixas[idx].status, "slotEdicaoAtual");
                    if(selN === n && selE === e) slot.classList.add("slotSelecionado");
                    slot.textContent = db.caixas[idx].caixa;
                    slot.title = "Posição atual desta caixa";
                    slot.onclick = () => {
                        document.getElementById("nivel").value = n;
                        document.getElementById("espaco").value = e;
                        atualizarResumoPosicao();
                        renderMapaLancamento();
                    };
                } else {
                    slot.classList.add("livre");
                    if(selN === n && selE === e) slot.classList.add("slotSelecionado");
                    slot.textContent = String(e);
                    slot.title = "Livre — clique para selecionar";
                    slot.onclick = () => {
                        document.getElementById("nivel").value = n;
                        document.getElementById("espaco").value = e;
                        atualizarResumoPosicao();
                        renderMapaLancamento();
                    };
                }
                linha.appendChild(slot);
            }
            box.appendChild(linha);
        }
        container.appendChild(box);
    }

    function limparAposSalvarSucesso(){
        const prat = document.getElementById("prateleiraSelect").value;
        const unid = document.getElementById("unidadeSelect").value;
        edit = null;
        document.getElementById("btnSalvar").innerText = "Salvar";
        document.getElementById("btnCancelar").style.display = "none";
        document.getElementById("caixa").value = "";
        document.getElementById("unidadeSelect").value = unid;
        document.getElementById("inicio").value = "";
        document.getElementById("fim").value = "";
        document.getElementById("validade").value = "";
        document.getElementById("usuarioStatus").value = "";
        document.getElementById("status").selectedIndex = 0;
        document.getElementById("status").value = "Avulsa";
        document.querySelectorAll('input[name="procCheck"]').forEach(cb => { cb.checked = false; });
        document.getElementById("nivel").value = "";
        document.getElementById("espaco").value = "";
        document.getElementById("prateleiraSelect").disabled = false;
        document.getElementById("prateleiraSelect").value = prat;
        const alerta = document.getElementById("alertaStatusLanc");
        if(alerta) alerta.style.display = "none";
        atualizarResumoPosicao();
        const ph = document.getElementById("mapaLancamentoPlaceholder");
        if(ph && !prat) ph.textContent = "Selecione uma prateleira para o mapa ou deixe em branco para caixa avulsa.";
        if(ph) ph.style.display = prat ? "none" : "block";
        renderMapaLancamento();
        const ok = document.getElementById("msgLancamentoOk");
        if(ok){
            ok.style.display = "inline";
            clearTimeout(window._msgLancOkT);
            window._msgLancOkT = setTimeout(() => { ok.style.display = "none"; }, 4500);
        }
    }

    async function salvar(e){
        e.preventDefault();
        await carregarDB(true);

        let stSalvar = document.getElementById("status").value;
        let prat = (document.getElementById("prateleiraSelect").value || "").trim();
        let nl = parseInt(document.getElementById("nivel").value, 10);
        let es = parseInt(document.getElementById("espaco").value, 10);

        // Validação de integridade de status vs localização
        if(!prat && stSalvar !== "Eliminada") {
            stSalvar = "Avulsa";
        } else if(prat && stSalvar === "Avulsa") {
            stSalvar = "Guardada";
        }

        if(stSalvar === "Eliminada"){
            prat = "";
            nl = 0;
            es = 0;
        } else if(!prat){
            nl = 0;
            es = 0;
        } else {
            if(isNaN(nl) || isNaN(es) || nl < 1 || nl > 13 || es < 1 || es > 6)
                return alert("Com prateleira selecionada, escolha um espaço livre no mapa.");
        }

        const procs = Array.from(document.querySelectorAll('input[name="procCheck"]:checked')).map(cb => cb.value);

        let historicoCarry = [];
        if(edit !== null && db.caixas[edit]){
            const h0 = db.caixas[edit].historico;
            historicoCarry = Array.isArray(h0) ? JSON.parse(JSON.stringify(h0)) : [];
        }

        const item = {
            caixa: document.getElementById("caixa").value,
            unidade: document.getElementById("unidadeSelect").value.trim(),
            inicio: document.getElementById("inicio").value,
            fim: document.getElementById("fim").value,
            validade: document.getElementById("validade").value,
            prateleira: prat,
            nivel: nl,
            espaco: es,
            status: stSalvar,
            usuario: document.getElementById("usuarioStatus").value,
            processos: procs,
            dataUpdate: new Date().toLocaleString(),
            historico: historicoCarry
        };

        if(caixaOcupaSlot(item)){
            const ocupado = db.caixas.find((c, idx) =>
                idx !== edit && caixaOcupaSlot(c) &&
                c.prateleira === item.prateleira && c.nivel === item.nivel && c.espaco === item.espaco
            );
            if(ocupado) return alert("Esta posição já está ocupada pela caixa " + ocupado.caixa + ". Escolha outro espaço no mapa.");
        }

        if(edit !== null){
            const antes = snapshotCaixaParaHistorico(db.caixas[edit]);
            const mud = extrairMudancasRegistro(antes, item);
            if(mud.length > 0)
                item.historico.push(criarEntradaHistorico("edicao", mud, item.usuario));
        } else {
            item.historico = [criarEntradaHistorico("criacao", mudancasIniciaisCadastro(item), item.usuario)];
        }

        if(edit !== null) db.caixas[edit] = item;
        else db.caixas.push(item);

        await salvarDB();
        limparAposSalvarSucesso();
        atualizarInterface();
    }

    function listar(){
        const lista = document.getElementById("lista");
        if(!lista) return;
        const buscaEl = document.getElementById("buscarCaixa");
        const busca = (buscaEl ? buscaEl.value : "").toLowerCase();

        const filtrados = db.caixas.filter(c =>
            c.caixa.toLowerCase().includes(busca) ||
            (c.unidade && String(c.unidade).toLowerCase().includes(busca)) ||
            (c.processos && c.processos.some(p => p.toLowerCase().includes(busca)))
        );

        lista.innerHTML = "";
        filtrados.forEach((c, i) => {
            const idxReal = db.caixas.indexOf(c);
            const unid = c.unidade ? `<span class="badge" style="background:#8e44ad">${c.unidade}</span>` : "—";
            const tagsProc = c.processos ? c.processos.map(p => `<span class="processo-tag">${p}</span>`).join('') : "";

            lista.innerHTML += `<tr onclick="detalhes(${idxReal})">
                <td><b>${c.caixa}</b></td>
                <td>${unid}</td>
                <td>${tagsProc}</td>
                <td><span class="badge" style="background:${getColor(c.status)}">${c.status}</span></td>
                <td>${formatarLocalCaixa(c)}</td>
                <td>
                    <button onclick="event.stopPropagation(); editar(${idxReal})">✏️</button>
                    <button style="background:#e74c3c" onclick="event.stopPropagation(); remover(${idxReal})">🗑️</button>
                </td>
            </tr>`;
        });
        mapa();
    }

    function getColor(s){
        const colors = {Guardada:'#27ae60', Avulsa:'#9b59b6', Preparada:'#f1c40f', Digitalizada:'#3498db', Eliminada:'#e74c3c'};
        return colors[s] || '#7f8c8d';
    }

    function editar(i){
        window.location.href = "lancamento.html?edit=" + encodeURIComponent(i);
    }

    function preencherFormularioEdicao(i){
        esconderMsgLancamentoOk();
        const c = db.caixas[i];
        if(!c) return;
        document.getElementById("caixa").value = c.caixa;
        document.getElementById("unidadeSelect").value = c.unidade || "";
        document.getElementById("inicio").value = c.inicio;
        document.getElementById("fim").value = c.fim;
        document.getElementById("validade").value = c.validade;
        document.getElementById("prateleiraSelect").value = c.prateleira || "";
        document.getElementById("nivel").value = (c.nivel && parseInt(c.nivel, 10) >= 1) ? c.nivel : "";
        document.getElementById("espaco").value = (c.espaco && parseInt(c.espaco, 10) >= 1) ? c.espaco : "";
        document.getElementById("status").value = c.status;
        document.getElementById("usuarioStatus").value = c.usuario;

        document.querySelectorAll('input[name="procCheck"]').forEach(cb => {
            cb.checked = c.processos && c.processos.includes(cb.value);
        });

        edit = i;
        document.getElementById("btnSalvar").innerText = "Atualizar";
        document.getElementById("btnCancelar").style.display = "inline-block";
        onStatusLancamentoChange();
        window.scrollTo(0, 0);
    }

    function cancelarEdicao(){
        esconderMsgLancamentoOk();
        edit = null;
        document.getElementById("prateleiraSelect").disabled = false;
        const alerta = document.getElementById("alertaStatusLanc");
        if(alerta) alerta.style.display = "none";
        document.getElementById("cadastroForm").reset();
        document.querySelectorAll('input[name="procCheck"]').forEach(cb => cb.checked = false);
        document.getElementById("btnSalvar").innerText = "Salvar";
        document.getElementById("btnCancelar").style.display = "none";
        atualizarResumoPosicao();
        const ph = document.getElementById("mapaLancamentoPlaceholder");
        if(ph){
            ph.style.display = "block";
            ph.textContent = "Selecione uma prateleira para o mapa ou deixe em branco para caixa avulsa.";
        }
        renderMapaLancamento();
    }

    async function remover(i){
        if(confirm("Excluir esta caixa?")){
            db.caixas.splice(i, 1);
            await salvarDB();
            atualizarInterface();
        }
    }

    // ---------------- MAPA E AUXS ----------------
    function mapa(){
        const container = document.getElementById("mapa");
        if(!container) return;
        container.innerHTML = "";
        db.prateleiras.forEach(p => {
            const box = document.createElement("div");
            box.className = "prateleiraBox";
            box.innerHTML = `<h3>${p.nome}</h3>`;
            for(let n=13; n>=1; n--){
                const linha = document.createElement("div"); linha.className = "nivel";
                linha.innerHTML = `<div class="nivelLabel">N${n}</div>`;
                for(let e=1; e<=6; e++){
                    const idx = db.caixas.findIndex(c => caixaOcupaSlot(c) && c.prateleira === p.nome && c.nivel === n && c.espaco === e);
                    const slot = document.createElement("div");
                    if(idx !== -1){
                        const cx = db.caixas[idx];
                        slot.className = "slot ocupado" + cx.status;
                        slot.innerText = cx.caixa;
                        slot.title = (cx.unidade ? cx.unidade + " · " : "") + cx.status + " · clique para detalhes";
                        slot.onclick = () => detalhes(idx);
                    } else {
                        slot.className = "slot livre"; slot.innerText = e;
                    }
                    linha.appendChild(slot);
                }
                box.appendChild(linha);
            }
            container.appendChild(box);
        });
    }

    function fecharMenuDropdown(){
        const menu = document.getElementById("menu");
        const ham = document.getElementById("hamburger");
        if(menu) menu.classList.remove("show");
        if(ham) ham.classList.remove("active");
    }

    function toggleMenu(){
        const menu = document.getElementById("menu");
        const ham = document.getElementById("hamburger");
        if(menu) menu.classList.toggle("show");
        if(ham) ham.classList.toggle("active");
    }

    function detalhes(i){
        const c = db.caixas[i];
        const procs = c.processos ? c.processos.join(", ") : "Nenhum";
        const mb = document.querySelector("#modal .modalBox");
        if(mb) mb.classList.add("modal-wide");
        document.getElementById("modalConteudo").innerHTML = `
            <h3>Caixa: ${escModal(c.caixa)}</h3>
            <p><b>Unidade:</b> ${escModal(c.unidade || "—")}</p>
            <p><b>Processos:</b> ${escModal(procs)}</p>
            <p><b>Local:</b> ${escModal(formatarLocalCaixa(c))}</p>
            <p><b>Status:</b> ${escModal(c.status)}</p>
            <p><b>Validade:</b> ${escModal(c.validade)}</p>
            <p><b>Responsável:</b> ${escModal(c.usuario)}</p>
            <p><small>Última atualização: ${escModal(c.dataUpdate || "N/A")}</small></p>
            <h4 style="margin:16px 0 6px 0;font-size:14px;color:#2c3e50;">Histórico</h4>
            <div class="historico-caixa">${renderHtmlHistorico(c)}</div>
            <hr>
            <button onclick="fecharModal()">Fechar</button>
        `;
        document.getElementById("modal").style.display = "flex";
    }
    function fecharModal(){
        document.getElementById("modal").style.display = "none";
        const mb = document.querySelector("#modal .modalBox");
        if(mb) mb.classList.remove("modal-wide");
    }
    function buscarCaixa(){ listar(); }

    function hojeISO(){
        const d = new Date();
        const z = n => String(n).padStart(2,"0");
        return `${d.getFullYear()}-${z(d.getMonth()+1)}-${z(d.getDate())}`;
    }

    function addDiasISO(dias){
        const d = new Date();
        d.setDate(d.getDate() + dias);
        const z = n => String(n).padStart(2,"0");
        return `${d.getFullYear()}-${z(d.getMonth()+1)}-${z(d.getDate())}`;
    }

    function preencherSelectsDashboard(){
        const selPrat = document.getElementById("dashPrateleira");
        if(!selPrat) return;
        const valPrat = selPrat.value;
        selPrat.innerHTML = '<option value="">Todas as prateleiras</option>';
        const oA = document.createElement("option");
        oA.value = "__avulsa__";
        oA.textContent = "Somente caixas avulsas (sem prateleira)";
        selPrat.appendChild(oA);
        db.prateleiras.forEach(p => {
            const o = document.createElement("option");
            o.value = p.nome;
            o.textContent = p.nome;
            selPrat.appendChild(o);
        });
        if([...selPrat.options].some(o => o.value === valPrat)) selPrat.value = valPrat;

        const selUn = document.getElementById("dashUnidade");
        if(selUn){
            const valUn = selUn.value;
            selUn.innerHTML = '<option value="">Todas as unidades</option>';
            (db.unidades || []).slice().sort((a, b) => a.localeCompare(b, "pt")).forEach(u => {
                const o = document.createElement("option");
                o.value = u;
                o.textContent = u;
                selUn.appendChild(o);
            });
            if([...selUn.options].some(o => o.value === valUn)) selUn.value = valUn;
        }

        const selProc = document.getElementById("dashProcesso");
        if(!selProc) return;
        const prev = dashProcessoInicializado ? [...selProc.selectedOptions].map(o => o.value) : null;
        selProc.innerHTML = "";
        db.processos.forEach(n => {
            const o = document.createElement("option");
            o.value = n;
            o.textContent = n;
            selProc.appendChild(o);
        });
        if(!dashProcessoInicializado){
            [...selProc.options].forEach(o => { o.selected = true; });
            dashProcessoInicializado = true;
        } else {
            [...selProc.options].forEach(o => { o.selected = prev.includes(o.value); });
            if([...selProc.options].every(o => !o.selected))
                [...selProc.options].forEach(o => { o.selected = true; });
        }
    }

    function caixasFiltradasDashboard(){
        const q = (document.getElementById("dashBusca").value || "").trim().toLowerCase();
        const rapido = document.getElementById("dashFiltroRapido").value;
        const vd = document.getElementById("dashValidadeDe").value;
        const va = document.getElementById("dashValidadeAte").value;
        const id = document.getElementById("dashInicioDe").value;
        const ia = document.getElementById("dashInicioAte").value;
        const prat = document.getElementById("dashPrateleira").value;
        const procOpts = document.getElementById("dashProcesso");
        const procSel = [...procOpts.selectedOptions].map(o => o.value);
        const todosProcs = db.processos.length === 0 || procSel.length === 0 || procSel.length === db.processos.length;
        const statusChecks = [...document.querySelectorAll('input[name="dashSt"]:checked')].map(i => i.value);
        const todosStatus = statusChecks.length === 5;
        const hoje = hojeISO();
        const lim30 = addDiasISO(30);
        const lim90 = addDiasISO(90);

        return db.caixas.filter(c => {
            if(q){
                const u = (c.usuario || "").toLowerCase();
                const cx = (c.caixa || "").toLowerCase();
                const ux = (c.unidade || "").toLowerCase();
                if(!cx.includes(q) && !u.includes(q) && !ux.includes(q)) return false;
            }
            if(rapido === "vencidas"){
                if(!c.validade || c.validade >= hoje) return false;
            } else if(rapido === "vence30"){
                if(!c.validade || c.validade < hoje || c.validade > lim30) return false;
            } else if(rapido === "vence90"){
                if(!c.validade || c.validade < hoje || c.validade > lim90) return false;
            }
            if(vd && (!c.validade || c.validade < vd)) return false;
            if(va && (!c.validade || c.validade > va)) return false;
            if(id && (!c.inicio || c.inicio < id)) return false;
            if(ia && (!c.inicio || c.inicio > ia)) return false;
            if(prat === "__avulsa__"){
                if(c.prateleira && String(c.prateleira).trim()) return false;
            } else if(prat && c.prateleira !== prat) return false;
            const unF = document.getElementById("dashUnidade") && document.getElementById("dashUnidade").value;
            if(unF && (c.unidade || "") !== unF) return false;
            if(!todosStatus && !statusChecks.includes(c.status)) return false;
            if(!todosProcs){
                const bp = c.processos || [];
                if(!procSel.some(p => bp.includes(p))) return false;
            }
            return true;
        });
    }

    function aplicarFiltrosDashboard(){ renderDashboardDados(); }

    function limparFiltrosDashboard(){
        document.getElementById("dashBusca").value = "";
        document.getElementById("dashFiltroRapido").value = "";
        document.getElementById("dashValidadeDe").value = "";
        document.getElementById("dashValidadeAte").value = "";
        document.getElementById("dashInicioDe").value = "";
        document.getElementById("dashInicioAte").value = "";
        document.getElementById("dashPrateleira").value = "";
        const du = document.getElementById("dashUnidade");
        if(du) du.value = "";
        document.querySelectorAll('input[name="dashSt"]').forEach(i => { i.checked = true; });
        const sp = document.getElementById("dashProcesso");
        [...sp.options].forEach(o => { o.selected = true; });
        renderDashboardDados();
    }

    function agregarParaGrafico(dim, caixas){
        const map = new Map();
        const coresStatus = { Guardada:"#27ae60", Preparada:"#f1c40f", Digitalizada:"#3498db", Eliminada:"#e74c3c", Avulsa:"#9b59b6" };

        if(dim === "status"){
            ["Guardada","Avulsa","Preparada","Digitalizada","Eliminada"].forEach(s => map.set(s, 0));
            caixas.forEach(c => {
                const k = c.status || "—";
                map.set(k, (map.get(k) || 0) + 1);
            });
        } else if(dim === "prateleira"){
            db.prateleiras.forEach(p => map.set(p.nome, 0));
            map.set("(Avulsa)", 0);
            caixas.forEach(c => {
                const k = (c.prateleira && String(c.prateleira).trim()) ? c.prateleira : "(Avulsa)";
                map.set(k, (map.get(k) || 0) + 1);
            });
        } else if(dim === "nivel"){
            for(let n = 1; n <= 13; n++) map.set("Nível " + n, 0);
            caixas.forEach(c => {
                const n = c.nivel;
                if(n >= 1 && n <= 13) map.set("Nível " + n, (map.get("Nível " + n) || 0) + 1);
            });
        } else if(dim === "usuario"){
            caixas.forEach(c => {
                const k = (c.usuario && String(c.usuario).trim()) ? String(c.usuario).trim() : "(não informado)";
                map.set(k, (map.get(k) || 0) + 1);
            });
        } else if(dim === "mes_validade"){
            caixas.forEach(c => {
                if(!c.validade || c.validade.length < 7) return;
                const k = c.validade.slice(0, 7);
                map.set(k, (map.get(k) || 0) + 1);
            });
        } else if(dim === "mes_inicio"){
            caixas.forEach(c => {
                if(!c.inicio || c.inicio.length < 7) return;
                const k = c.inicio.slice(0, 7);
                map.set(k, (map.get(k) || 0) + 1);
            });
        } else if(dim === "processo"){
            caixas.forEach(c => {
                const ps = (c.processos && c.processos.length) ? c.processos : ["(sem processo)"];
                ps.forEach(p => map.set(p, (map.get(p) || 0) + 1));
            });
        } else if(dim === "unidade"){
            caixas.forEach(c => {
                const k = (c.unidade && String(c.unidade).trim()) ? String(c.unidade).trim() : "(sem unidade)";
                map.set(k, (map.get(k) || 0) + 1);
            });
        }

        let entries = [...map.entries()].filter(([, v]) => v > 0);
        if((dim === "processo" || dim === "unidade") && entries.length > 12){
            entries.sort((a, b) => b[1] - a[1]);
            const top = entries.slice(0, 11);
            const rest = entries.slice(11).reduce((s, x) => s + x[1], 0);
            entries = [...top, ["Outros", rest]];
        }
        if((dim === "mes_validade" || dim === "mes_inicio") && entries.length){
            entries.sort((a, b) => a[0].localeCompare(b[0]));
        }
        const labels = entries.map(x => x[0]);
        const values = entries.map(x => x[1]);
        return { labels, values, coresStatus, dim };
    }

    function paletaCores(n, dim, labels, coresStatus){
        const base = ["#3498db","#9b59b6","#1abc9c","#e67e22","#34495e","#16a085","#d35400","#8e44ad","#27ae60","#c0392b","#2980b9","#f39c12","#7f8c8d","#2ecc71","#e74c3c"];
        return labels.map((lb, i) => {
            if(dim === "status" && coresStatus[lb]) return coresStatus[lb];
            return base[i % base.length];
        });
    }

    function destruirDashboardCharts(){
        [_dashChart1, _dashChart2].forEach(ch => {
            if(ch){ ch.destroy(); }
        });
        _dashChart1 = _dashChart2 = null;
    }

    function montarChart(canvasId, dimSelectId, tipoSelectId, caixas){
        const canvas = document.getElementById(canvasId);
        if(!canvas) return;
        const wrap = canvas.closest(".chart-wrap");
        const dim = document.getElementById(dimSelectId).value;
        const tipo = document.getElementById(tipoSelectId).value;
        const { labels, values, coresStatus } = agregarParaGrafico(dim, caixas);
        const semDados = !values.length || values.every(v => v === 0);

        let alvoMsg = wrap.querySelector(".dash-chart-msg");
        if(!alvoMsg){
            alvoMsg = document.createElement("div");
            alvoMsg.className = "dash-empty dash-chart-msg";
            wrap.appendChild(alvoMsg);
        }
        if(semDados){
            canvas.style.display = "none";
            alvoMsg.style.display = "block";
            alvoMsg.textContent = "Nenhum dado para os filtros atuais nesta dimensão.";
            return;
        }
        canvas.style.display = "block";
        alvoMsg.style.display = "none";

        const cores = paletaCores(labels.length, dim, labels, coresStatus);
        const ctx = canvas.getContext("2d");
        const isCartesian = tipo === "bar" || tipo === "line";
        const cfg = {
            type: tipo,
            data: {
                labels,
                datasets: [{
                    label: "Quantidade",
                    data: values,
                    backgroundColor: isCartesian ? cores.map(c => tipo === "line" ? "rgba(52,152,219,0.25)" : c) : cores,
                    borderColor: tipo === "line" ? "#2980b9" : isCartesian ? cores : "#fff",
                    borderWidth: isCartesian ? 1 : 2,
                    fill: tipo === "line"
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: tipo === "pie" || tipo === "doughnut" || tipo === "polarArea" }
                },
                scales: isCartesian ? {
                    y: { beginAtZero: true, ticks: { precision: 0 } },
                    x: { ticks: { maxRotation: 45, minRotation: 0 } }
                } : {}
            }
        };
        if(tipo === "line"){
            cfg.data.datasets[0].backgroundColor = "rgba(52,152,219,0.2)";
            cfg.data.datasets[0].borderColor = "#2980b9";
            cfg.data.datasets[0].borderWidth = 2;
            cfg.data.datasets[0].tension = 0.25;
        }

        const inst = new Chart(ctx, cfg);
        if(canvasId === "chartDashboard1") _dashChart1 = inst;
        else _dashChart2 = inst;
    }

    function renderKpis(filtradas){
        const el = document.getElementById("dashboardKpis");
        if(!el) return;
        const hoje = hojeISO();
        const lim30 = addDiasISO(30);
        const vencidas = filtradas.filter(c => c.validade && c.validade < hoje).length;
        const vence30 = filtradas.filter(c => c.validade && c.validade >= hoje && c.validade <= lim30).length;

        const ocupamSlot = filtradas.filter(caixaOcupaSlot).length;
        const comPratNome = filtradas.filter(c => c.prateleira && String(c.prateleira).trim());
        const pratsUsadas = new Set(comPratNome.map(c => c.prateleira));
        let cap = 0;
        db.prateleiras.forEach(p => {
            if(pratsUsadas.has(p.nome)) cap += (p.capacidade || 78);
        });
        if(cap === 0 && ocupamSlot > 0){
            cap = pratsUsadas.size * 78;
        }
        const pctOcup = cap ? Math.min(100, Math.round((ocupamSlot / cap) * 100)) : 0;

        const porSt = {};
        filtradas.forEach(c => { porSt[c.status] = (porSt[c.status] || 0) + 1; });
        const badges = ["Guardada","Avulsa","Preparada","Digitalizada","Eliminada"].map(s => {
            const n = porSt[s] || 0;
            const bg = getColor(s);
            return `<span class="badge" style="background:${bg}">${s}: ${n}</span>`;
        }).join(" ");

        el.innerHTML = `
            <div class="kpi-card">
                <div class="kpi-lbl">Caixas no filtro</div>
                <div class="kpi-val">${filtradas.length}</div>
                <div class="kpi-sub">Total no banco: ${db.caixas.length}</div>
            </div>
            <div class="kpi-card">
                <div class="kpi-lbl">Ocupação estimada</div>
                <div class="kpi-val">${cap ? pctOcup + "%" : "—"}</div>
                <div class="kpi-sub">${ocupamSlot} ocupam posição · ${filtradas.length} no filtro · ref.: ${pratsUsadas.size} prat. · ${cap || "—"} pos.</div>
            </div>
            <div class="kpi-card">
                <div class="kpi-lbl">Validade</div>
                <div class="kpi-val" style="color:#e74c3c">${vencidas}</div>
                <div class="kpi-sub">Vencidas · <span style="color:#f39c12">${vence30}</span> a vencer em 30 dias</div>
            </div>
            <div class="kpi-card" style="flex:2;min-width:220px;">
                <div class="kpi-lbl">Distribuição por status</div>
                <div class="kpi-inline">${badges}</div>
            </div>
        `;
    }

    function renderDashboardDados(){
        preencherSelectsDashboard();
        const filtradas = caixasFiltradasDashboard();
        renderKpis(filtradas);
        destruirDashboardCharts();
        montarChart("chartDashboard1", "dashDim1", "dashTipo1", filtradas);
        montarChart("chartDashboard2", "dashDim2", "dashTipo2", filtradas);
    }

    function atualizarDashboard(){
        if(!document.getElementById("dashBusca")) return;
        renderDashboardDados();
    }

    (function initDashboardUI(){
        const reagir = ["dashDim1","dashTipo1","dashDim2","dashTipo2"];
        reagir.forEach(id => {
            const n = document.getElementById(id);
            if(n) n.addEventListener("change", () => {
                if(document.getElementById("dashBusca")) renderDashboardDados();
            });
        });
    })();

    // ---------------- GESTÃO DE AVULSAS ----------------
    function renderAvulsas() {
        const tbody = document.getElementById("listaAvulsas");
        if (!tbody) return;
        tbody.innerHTML = "";
        
        // Exibe apenas caixas que estão como Avulsas e realmente não tem endereço
        const avulsas = db.caixas.filter(c => c.status === "Avulsa" && (!c.prateleira || !c.prateleira.trim()));

        if (avulsas.length === 0) {
            tbody.innerHTML = "<tr><td colspan='4'>Nenhuma caixa avulsa encontrada.</td></tr>";
            return;
        }

        avulsas.forEach(c => {
            const idxReal = db.caixas.indexOf(c);
            tbody.innerHTML += `<tr>
                <td><b>${escModal(c.caixa)}</b></td>
                <td>${escModal(c.unidade || "—")}</td>
                <td><span class="badge" style="background:${getColor(c.status)}">${c.status}</span></td>
                <td><button onclick="editar(${idxReal})">Escolher Prateleira</button></td>
            </tr>`;
        });
    }

    async function alocarTudoAutomatico() {
        const avulsas = db.caixas.filter(c => c.status === "Avulsa" && (!c.prateleira || !c.prateleira.trim()) && c.status !== "Eliminada");

        if (avulsas.length === 0) return alert("Não há caixas avulsas para alocar.");
        if (db.prateleiras.length === 0) return alert("Cadastre ao menos uma prateleira primeiro.");

        let alocadasCont = 0;
        let logs = [];

        for (let c of avulsas) {
            let alocada = false;
            // Tenta encontrar o primeiro buraco vago em qualquer prateleira
            for (let p of db.prateleiras) {
                for (let n = 1; n <= 13; n++) {
                    for (let e = 1; e <= 6; e++) {
                        const ocupado = db.caixas.some(cx => caixaOcupaSlot(cx) && cx.prateleira === p.nome && cx.nivel === n && cx.espaco === e);
                        if (!ocupado) {
                            const antesLocal = "Avulsa";
                            c.prateleira = p.nome; 
                            c.nivel = n;
                            c.espaco = e;
                            c.status = "Guardada";
                            c.dataUpdate = new Date().toLocaleString();
                            
                            const mudanca = [{ campo: "localizacao", label: "Localização", de: antesLocal, para: formatarLocalCaixa(c) }];
                            c.historico.push(criarEntradaHistorico("edicao", mudanca, "Sistema (Auto)"));
                            
                            logs.push(`Caixa ${c.caixa} -> ${p.nome} (N${n}-S${e})`);
                            alocada = true;
                            alocadasCont++;
                            break;
                        }
                    }
                    if (alocada) break;
                }
                if (alocada) break;
            }
            if (!alocada) break; // Sem mais espaço no sistema
        }

        if (alocadasCont > 0) {
            await salvarDB();
            atualizarInterface();
            alert(`Sucesso! ${alocadasCont} caixa(s) foram alocadas automaticamente.`);
        } else {
            alert("Não foi possível alocar. Verifique se há espaço disponível nas prateleiras.");
        }
    }

    function gerarRelatorioLocalizacao() {
        const caixasComLocal = db.caixas
            .filter(c => {
                const temLocal = c.prateleira && c.prateleira.trim() !== "";
                const foiAlocada = c.historico && c.historico.some(h => 
                    h.mudancas && h.mudancas.some(m => m.campo === "localizacao" && (m.de === "Avulsa" || m.de === "Avulsa (sem prateleira)"))
                );
                return temLocal && foiAlocada && c.status !== "Eliminada";
            })
            .sort((a, b) => (a.prateleira || "").localeCompare(b.prateleira || "") || a.nivel - b.nivel || a.espaco - b.espaco);

        let html = `<h3>Relatório de Localização de Estoque</h3>
                    <table style="font-size: 12px; width: 100%;">
                        <thead><tr><th>Endereço</th><th>Caixa</th><th>Unidade</th><th>Status</th></tr></thead>
                        <tbody>`;

        caixasComLocal.forEach(c => {
            html += `<tr>
                <td>${formatarLocalCaixa(c)}</td>
                <td>${escModal(c.caixa)}</td>
                <td>${escModal(c.unidade || "—")}</td>
                <td>${c.status}</td>
            </tr>`;
        });

        html += `</tbody></table><br><button onclick="window.print()">Imprimir Relatório</button> <button onclick="fecharModal()">Fechar</button>`;
        
        const mb = document.querySelector("#modal .modalBox");
        if(mb) mb.classList.add("modal-wide");
        document.getElementById("modalConteudo").innerHTML = html;
        document.getElementById("modal").style.display = "flex";
    }
